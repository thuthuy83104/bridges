<?php

/** Landing page template */
$data               = array();


vc_add_default_templates( $data );


